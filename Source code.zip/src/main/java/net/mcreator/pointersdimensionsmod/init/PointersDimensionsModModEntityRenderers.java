
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.pointersdimensionsmod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.pointersdimensionsmod.client.renderer.PibRenderer;
import net.mcreator.pointersdimensionsmod.client.renderer.CrimsonZombieRenderer;
import net.mcreator.pointersdimensionsmod.client.renderer.CrimsonSpiderRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class PointersDimensionsModModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(PointersDimensionsModModEntities.CRIMSON_SPIDER, CrimsonSpiderRenderer::new);
		event.registerEntityRenderer(PointersDimensionsModModEntities.CRIMSON_ZOMBIE, CrimsonZombieRenderer::new);
		event.registerEntityRenderer(PointersDimensionsModModEntities.PIB, PibRenderer::new);
	}
}
