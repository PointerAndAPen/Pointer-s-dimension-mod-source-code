package net.mcreator.pointersdimensionsmod.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.SpiderModel;

import net.mcreator.pointersdimensionsmod.entity.CrimsonSpiderEntity;

public class CrimsonSpiderRenderer extends MobRenderer<CrimsonSpiderEntity, SpiderModel<CrimsonSpiderEntity>> {
	public CrimsonSpiderRenderer(EntityRendererProvider.Context context) {
		super(context, new SpiderModel(context.bakeLayer(ModelLayers.SPIDER)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(CrimsonSpiderEntity entity) {
		return new ResourceLocation("pointers_dimensions_mod:textures/crimsonspdertext.png");
	}
}
