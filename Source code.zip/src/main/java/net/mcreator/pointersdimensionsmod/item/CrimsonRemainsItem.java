
package net.mcreator.pointersdimensionsmod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;

public class CrimsonRemainsItem extends Item {
	public CrimsonRemainsItem() {
		super(new Item.Properties().tab(CreativeModeTab.TAB_MISC).stacksTo(64).fireResistant().rarity(Rarity.EPIC));
		setRegistryName("crimson_remains");
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 0;
	}
}
