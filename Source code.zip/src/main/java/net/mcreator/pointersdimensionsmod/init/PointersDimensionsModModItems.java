
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.pointersdimensionsmod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.pointersdimensionsmod.item.FermentedCrimsonSpiderEyeItem;
import net.mcreator.pointersdimensionsmod.item.CrimsonSwordItem;
import net.mcreator.pointersdimensionsmod.item.CrimsonSpiderEyeItem;
import net.mcreator.pointersdimensionsmod.item.CrimsonShovelItem;
import net.mcreator.pointersdimensionsmod.item.CrimsonRemainsItem;
import net.mcreator.pointersdimensionsmod.item.CrimsonPickaxeItem;
import net.mcreator.pointersdimensionsmod.item.CrimsonOreActuallyNotBlockItem;
import net.mcreator.pointersdimensionsmod.item.CrimsonIngotItem;
import net.mcreator.pointersdimensionsmod.item.CrimsonHoeItem;
import net.mcreator.pointersdimensionsmod.item.CrimsonDimensionItem;
import net.mcreator.pointersdimensionsmod.item.CrimsonAxeItem;
import net.mcreator.pointersdimensionsmod.item.CrimsonArmourItem;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class PointersDimensionsModModItems {
	private static final List<Item> REGISTRY = new ArrayList<>();
	public static final Item CRIMSON_GRASS_BLOCK = register(PointersDimensionsModModBlocks.CRIMSON_GRASS_BLOCK, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item CRIMSON_LEAVES = register(PointersDimensionsModModBlocks.CRIMSON_LEAVES, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item CRIMSON_DIMENSION = register(new CrimsonDimensionItem());
	public static final Item CRIMSON_SPIDER = register(
			new SpawnEggItem(PointersDimensionsModModEntities.CRIMSON_SPIDER, -65536, -16711908, new Item.Properties().tab(CreativeModeTab.TAB_MISC))
					.setRegistryName("crimson_spider_spawn_egg"));
	public static final Item CRIMSON_SPIDER_EYE = register(new CrimsonSpiderEyeItem());
	public static final Item FERMENTED_CRIMSON_SPIDER_EYE = register(new FermentedCrimsonSpiderEyeItem());
	public static final Item CRIMSON_ZOMBIE = register(
			new SpawnEggItem(PointersDimensionsModModEntities.CRIMSON_ZOMBIE, -65536, -16740081, new Item.Properties().tab(CreativeModeTab.TAB_MISC))
					.setRegistryName("crimson_zombie_spawn_egg"));
	public static final Item CRIMSON_ORE = register(PointersDimensionsModModBlocks.CRIMSON_ORE, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final Item CRIMSON_ORE_ACTUALLY_NOT_BLOCK = register(new CrimsonOreActuallyNotBlockItem());
	public static final Item CRIMSON_REMAINS = register(new CrimsonRemainsItem());
	public static final Item CRIMSON_INGOT = register(new CrimsonIngotItem());
	public static final Item CRIMSON_SWORD = register(new CrimsonSwordItem());
	public static final Item CRIMSON_ARMOUR_HELMET = register(new CrimsonArmourItem.Helmet());
	public static final Item CRIMSON_ARMOUR_CHESTPLATE = register(new CrimsonArmourItem.Chestplate());
	public static final Item CRIMSON_ARMOUR_LEGGINGS = register(new CrimsonArmourItem.Leggings());
	public static final Item CRIMSON_ARMOUR_BOOTS = register(new CrimsonArmourItem.Boots());
	public static final Item CRIMSON_PICKAXE = register(new CrimsonPickaxeItem());
	public static final Item CRIMSON_AXE = register(new CrimsonAxeItem());
	public static final Item CRIMSON_SHOVEL = register(new CrimsonShovelItem());
	public static final Item CRIMSON_HOE = register(new CrimsonHoeItem());
	public static final Item PIB = register(
			new SpawnEggItem(PointersDimensionsModModEntities.PIB, -256, -103, new Item.Properties().tab(CreativeModeTab.TAB_MISC))
					.setRegistryName("pib_spawn_egg"));

	private static Item register(Item item) {
		REGISTRY.add(item);
		return item;
	}

	private static Item register(Block block, CreativeModeTab tab) {
		return register(new BlockItem(block, new Item.Properties().tab(tab)).setRegistryName(block.getRegistryName()));
	}

	@SubscribeEvent
	public static void registerItems(RegistryEvent.Register<Item> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new Item[0]));
	}
}
