
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.pointersdimensionsmod.init;

import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.pointersdimensionsmod.entity.PibEntity;
import net.mcreator.pointersdimensionsmod.entity.CrimsonZombieEntity;
import net.mcreator.pointersdimensionsmod.entity.CrimsonSpiderEntity;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class PointersDimensionsModModEntities {
	private static final List<EntityType<?>> REGISTRY = new ArrayList<>();
	public static final EntityType<CrimsonSpiderEntity> CRIMSON_SPIDER = register("crimson_spider",
			EntityType.Builder.<CrimsonSpiderEntity>of(CrimsonSpiderEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(CrimsonSpiderEntity::new).sized(1.4f, 0.9f));
	public static final EntityType<CrimsonZombieEntity> CRIMSON_ZOMBIE = register("crimson_zombie",
			EntityType.Builder.<CrimsonZombieEntity>of(CrimsonZombieEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(CrimsonZombieEntity::new).sized(0.6f, 1.8f));
	public static final EntityType<PibEntity> PIB = register("pib",
			EntityType.Builder.<PibEntity>of(PibEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
					.setUpdateInterval(3).setCustomClientFactory(PibEntity::new).sized(0.6f, 1.8f));

	private static <T extends Entity> EntityType<T> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		EntityType<T> entityType = (EntityType<T>) entityTypeBuilder.build(registryname).setRegistryName(registryname);
		REGISTRY.add(entityType);
		return entityType;
	}

	@SubscribeEvent
	public static void registerEntities(RegistryEvent.Register<EntityType<?>> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new EntityType[0]));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			CrimsonSpiderEntity.init();
			CrimsonZombieEntity.init();
			PibEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(CRIMSON_SPIDER, CrimsonSpiderEntity.createAttributes().build());
		event.put(CRIMSON_ZOMBIE, CrimsonZombieEntity.createAttributes().build());
		event.put(PIB, PibEntity.createAttributes().build());
	}
}
