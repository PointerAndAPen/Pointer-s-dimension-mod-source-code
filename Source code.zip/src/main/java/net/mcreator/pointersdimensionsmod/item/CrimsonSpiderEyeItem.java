
package net.mcreator.pointersdimensionsmod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;

public class CrimsonSpiderEyeItem extends Item {
	public CrimsonSpiderEyeItem() {
		super(new Item.Properties().tab(CreativeModeTab.TAB_MISC).stacksTo(64).rarity(Rarity.RARE));
		setRegistryName("crimson_spider_eye");
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 0;
	}
}
