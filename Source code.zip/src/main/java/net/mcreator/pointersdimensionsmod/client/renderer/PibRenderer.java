package net.mcreator.pointersdimensionsmod.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.pointersdimensionsmod.entity.PibEntity;
import net.mcreator.pointersdimensionsmod.client.model.Modelcustom_model;

public class PibRenderer extends MobRenderer<PibEntity, Modelcustom_model<PibEntity>> {
	public PibRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelcustom_model(context.bakeLayer(Modelcustom_model.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(PibEntity entity) {
		return new ResourceLocation("pointers_dimensions_mod:textures/pib.png");
	}
}
