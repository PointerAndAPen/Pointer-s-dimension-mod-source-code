
package net.mcreator.pointersdimensionsmod.item;

import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;

import net.mcreator.pointersdimensionsmod.init.PointersDimensionsModModItems;

public class CrimsonSwordItem extends SwordItem {
	public CrimsonSwordItem() {
		super(new Tier() {
			public int getUses() {
				return 2531;
			}

			public float getSpeed() {
				return 7f;
			}

			public float getAttackDamageBonus() {
				return 2.3f;
			}

			public int getLevel() {
				return 5;
			}

			public int getEnchantmentValue() {
				return 2;
			}

			public Ingredient getRepairIngredient() {
				return Ingredient.of(new ItemStack(PointersDimensionsModModItems.CRIMSON_INGOT));
			}
		}, 3, -1.3f, new Item.Properties().tab(CreativeModeTab.TAB_COMBAT).fireResistant());
		setRegistryName("crimson_sword");
	}

	@Override
	public boolean isFoil(ItemStack itemstack) {
		return true;
	}
}
